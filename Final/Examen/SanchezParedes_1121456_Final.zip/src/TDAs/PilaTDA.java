package TDAs;

public interface PilaTDA {
    void apilar(int x);
    void desapilar();
    int tope();
    boolean pilaVacia();
    void inicializarPila();
}
