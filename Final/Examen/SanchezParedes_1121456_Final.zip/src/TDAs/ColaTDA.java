package TDAs;

public interface ColaTDA{
    void acolar(int x);
    void desacolar();
    int primero();
    boolean colaVacia();
    void inicializarCola();
}
