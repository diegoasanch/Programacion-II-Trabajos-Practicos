Diciembre 11, 2020

Los ejercicios solicitados se encurentran en el directorio src/Ejercicios, cada uno con
su nombre correspondiente.

Los ejercicios A y B fueron realizados en el lenguaje Java, el ejercicio C es un diagrama en formato
PDF en el cual se justifican las respuestas y se detalla paso a paso los movimientos realizados.

Los directorios de src/Implementaciones y src/TDAs contienen las interfases e implementaciones de apoyo
que se utilizaron en los ejercicios A y B.

:)

@author Diego Sanchez
